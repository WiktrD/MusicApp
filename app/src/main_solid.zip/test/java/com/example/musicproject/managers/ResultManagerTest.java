package com.example.musicproject.managers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.example.musicproject.database.GameScore;
import com.example.musicproject.database.GameTypes;
import com.example.musicproject.database.ScoreDao;

import org.junit.Test;
import org.mockito.ArgumentCaptor;

public class ResultManagerTest {

    @Test
    public void scoreIsCorrectMinusIncorrect() {
        ResultManager manager = new ResultManager(GameTypes.QUIZ, mock(ScoreDao.class), Runnable::run);
        manager.recordAnswer(true);
        manager.recordAnswer(true);
        manager.recordAnswer(false);

        assertEquals(1, manager.getScore());
    }

    @Test
    public void finishSavesOnlyOnce() {
        ScoreDao dao = mock(ScoreDao.class);
        ResultManager manager = new ResultManager(GameTypes.PIANO, dao, Runnable::run);
        manager.recordAnswer(true);
        manager.recordAnswer(false);
        manager.recordAnswer(true);

        manager.finish();
        manager.finish();

        ArgumentCaptor<GameScore> captor = ArgumentCaptor.forClass(GameScore.class);
        verify(dao, times(1)).insertScoreSync(captor.capture());
        assertEquals(GameTypes.PIANO, captor.getValue().getGameType());
        assertEquals(1, captor.getValue().getPoints());
        assertEquals(2, captor.getValue().getCorrectCount());
        assertEquals(1, captor.getValue().getIncorrectCount());
    }

    @Test
    public void answersAfterFinishAreIgnored() {
        ScoreDao dao = mock(ScoreDao.class);
        ResultManager manager = new ResultManager(GameTypes.STAFF, dao, Runnable::run);
        manager.finish();
        manager.recordAnswer(true);

        assertTrue(manager.isFinished());
        assertEquals(0, manager.getCorrect());
        verify(dao, times(1)).insertScoreSync(any(GameScore.class));
    }
}
