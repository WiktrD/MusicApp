package com.example.musicproject.fakes;

import com.example.musicproject.managers.NotePlayer;

import java.util.ArrayList;
import java.util.List;

public class FakeNotePlayer implements NotePlayer {
    public final List<Integer> playedMidiNotes = new ArrayList<>();
    public final List<Integer> stoppedMidiNotes = new ArrayList<>();
    public final List<String> playedNoteNames = new ArrayList<>();

    @Override
    public void playNote(int midiNote) {
        playedMidiNotes.add(midiNote);
    }

    @Override
    public void stopNote(int midiNote) {
        stoppedMidiNotes.add(midiNote);
    }

    @Override
    public void playNoteByName(String noteName, int durationMillis) {
        playedNoteNames.add(noteName);
    }
}
