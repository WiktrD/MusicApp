package com.example.musicproject.managers;

import static org.junit.Assert.assertEquals;

import com.example.musicproject.database.GameScore;
import com.example.musicproject.database.GameTypes;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;

public class ScoreStatisticsTest {

    private static GameScore score(int points, int correct, int incorrect) {
        return new GameScore(0, GameTypes.PIANO, points, correct, incorrect, 0L);
    }

    @Test
    public void bestPointsOfEmptyOrNullListIsZero() {
        assertEquals(0, ScoreStatistics.bestPoints(Collections.emptyList()));
        assertEquals(0, ScoreStatistics.bestPoints(null));
    }

    @Test
    public void bestPointsReturnsTheHighestValueEvenWhenNegative() {
        assertEquals(7, ScoreStatistics.bestPoints(Arrays.asList(score(3, 4, 1), score(7, 8, 1))));
        assertEquals(-1, ScoreStatistics.bestPoints(Arrays.asList(score(-3, 1, 4), score(-1, 2, 3))));
    }

    @Test
    public void bestAccuracyIsPercentageOfCorrectAnswers() {
        assertEquals(80, ScoreStatistics.bestAccuracy(Arrays.asList(score(3, 4, 1), score(0, 1, 1))));
    }

    @Test
    public void bestAccuracyIgnoresGamesWithoutAnswers() {
        assertEquals(0, ScoreStatistics.bestAccuracy(Collections.singletonList(score(0, 0, 0))));
    }
}
