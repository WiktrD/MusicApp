package com.example.musicproject.fragmentsModels.Game.quiz;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;

import com.example.musicproject.database.GameScore;
import com.example.musicproject.database.GameTypes;
import com.example.musicproject.database.ScoreDao;
import com.example.musicproject.managers.QuestionRepository;
import com.example.musicproject.managers.ResultManager;
import com.example.musicproject.models.QuizQuestion;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class QuizViewModelTest {

    @Rule
    public InstantTaskExecutorRule instantTaskExecutorRule = new InstantTaskExecutorRule();

    private ScoreDao dao;
    private QuizViewModel viewModel;

    /** Pool of 8 questions; the correct answer is always option 0. */
    private final QuestionRepository repository = () -> {
        List<QuizQuestion> questions = new ArrayList<>();
        for (int i = 1; i <= 8; i++) {
            questions.add(new QuizQuestion("q" + i, Arrays.asList("a", "b", "c", "d"), 0));
        }
        return questions;
    };

    @Before
    public void setUp() {
        dao = mock(ScoreDao.class);
        ResultManager resultManager = new ResultManager(GameTypes.QUIZ, dao, Runnable::run);
        viewModel = new QuizViewModel(repository, resultManager, new Random(1));
    }

    @Test
    public void wrongAnswerKeepsTheSameQuestion() {
        QuizQuestion before = viewModel.getCurrentQuestion().getValue();

        viewModel.submitAnswer(1);

        assertEquals(before, viewModel.getCurrentQuestion().getValue());
        assertEquals(Boolean.FALSE, viewModel.getAnswerResult().getValue().getContentIfNotHandled());
    }

    @Test
    public void quizEndsAfterFiveCorrectAnswersAndSavesTheScoreOnce() {
        for (int i = 0; i < 4; i++) {
            viewModel.submitAnswer(0);
        }
        assertNull(viewModel.getQuizFinished().getValue());

        viewModel.submitAnswer(0);

        assertEquals(Integer.valueOf(5), viewModel.getQuizFinished().getValue().getContentIfNotHandled());
        viewModel.submitAnswer(0); // ignored: the quiz is finished
        verify(dao, times(1)).insertScoreSync(any(GameScore.class));
    }

    @Test
    public void mistakesLowerTheSavedScore() {
        viewModel.submitAnswer(1); // one mistake
        for (int i = 0; i < 5; i++) {
            viewModel.submitAnswer(0);
        }

        ArgumentCaptor<GameScore> captor = ArgumentCaptor.forClass(GameScore.class);
        verify(dao).insertScoreSync(captor.capture());
        assertEquals(4, captor.getValue().getPoints());
        assertEquals(5, captor.getValue().getCorrectCount());
        assertEquals(1, captor.getValue().getIncorrectCount());
    }
}
