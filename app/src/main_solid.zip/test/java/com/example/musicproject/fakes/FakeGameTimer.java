package com.example.musicproject.fakes;

import com.example.musicproject.managers.GameTimer;

/** Timer that never ticks by itself: tests call listener.onTick/onFinish manually. */
public class FakeGameTimer implements GameTimer {
    public Listener listener;
    public boolean cancelled;

    @Override
    public void start(long durationMillis, Listener listener) {
        this.listener = listener;
    }

    @Override
    public void cancel() {
        cancelled = true;
    }
}
