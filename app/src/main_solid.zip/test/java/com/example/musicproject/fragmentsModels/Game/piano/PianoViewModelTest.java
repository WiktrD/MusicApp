package com.example.musicproject.fragmentsModels.Game.piano;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;

import com.example.musicproject.database.GameScore;
import com.example.musicproject.database.GameTypes;
import com.example.musicproject.database.ScoreDao;
import com.example.musicproject.fakes.FakeGameTimer;
import com.example.musicproject.fakes.FakeNotePlayer;
import com.example.musicproject.managers.ResultManager;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import java.util.Random;

public class PianoViewModelTest {

    @Rule
    public InstantTaskExecutorRule instantTaskExecutorRule = new InstantTaskExecutorRule();

    private ScoreDao dao;
    private FakeGameTimer timer;
    private FakeNotePlayer player;
    private PianoViewModel viewModel;

    @Before
    public void setUp() {
        dao = mock(ScoreDao.class);
        timer = new FakeGameTimer();
        player = new FakeNotePlayer();
        ResultManager resultManager = new ResultManager(GameTypes.PIANO, dao, Runnable::run);
        viewModel = new PianoViewModel(player, resultManager, timer, new Random(1));
    }

    @Test
    public void targetNoteIsWithinOneOctaveAboveMiddleC() {
        int target = viewModel.getTargetNoteLive().getValue();

        assertTrue(target >= 60 && target < 72);
    }

    @Test
    public void correctKeyIsCounted() {
        viewModel.checkNote(viewModel.getTargetNoteLive().getValue());

        assertEquals(Integer.valueOf(1), viewModel.getCorrectCountLive().getValue());
        assertEquals(Boolean.TRUE, viewModel.getAnswerResult().getValue().getContentIfNotHandled());
    }

    @Test
    public void wrongKeyIsCounted() {
        int wrong = viewModel.getTargetNoteLive().getValue() == 60 ? 61 : 60;

        viewModel.checkNote(wrong);

        assertEquals(Integer.valueOf(1), viewModel.getIncorrectCountLive().getValue());
    }

    @Test
    public void keysAreForwardedToThePlayer() {
        viewModel.playNote(64);
        viewModel.stopNote(64);

        assertEquals(Integer.valueOf(64), player.playedMidiNotes.get(0));
        assertEquals(Integer.valueOf(64), player.stoppedMidiNotes.get(0));
    }

    @Test
    public void finishingTheGameSavesTheScoreOnceAndEmitsIt() {
        viewModel.checkNote(viewModel.getTargetNoteLive().getValue());

        timer.listener.onFinish();
        timer.listener.onFinish();

        verify(dao, times(1)).insertScoreSync(any(GameScore.class));
        assertEquals(Integer.valueOf(1), viewModel.getGameFinished().getValue().getContentIfNotHandled());
    }
}
