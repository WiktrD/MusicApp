package com.example.musicproject.fragmentsModels.Game.staff;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;

import com.example.musicproject.database.GameScore;
import com.example.musicproject.database.GameTypes;
import com.example.musicproject.database.ScoreDao;
import com.example.musicproject.fakes.FakeGameTimer;
import com.example.musicproject.fakes.FakeNotePlayer;
import com.example.musicproject.managers.NoteChallenge;
import com.example.musicproject.managers.ResultManager;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import java.util.Random;

public class StaffViewModelTest {

    @Rule
    public InstantTaskExecutorRule instantTaskExecutorRule = new InstantTaskExecutorRule();

    private ScoreDao dao;
    private FakeGameTimer timer;
    private FakeNotePlayer player;
    private StaffViewModel viewModel;

    @Before
    public void setUp() {
        dao = mock(ScoreDao.class);
        timer = new FakeGameTimer();
        player = new FakeNotePlayer();
        ResultManager resultManager = new ResultManager(GameTypes.STAFF, dao, Runnable::run);
        viewModel = new StaffViewModel(player, resultManager, new NoteChallenge(new Random(1)), timer);
    }

    @Test
    public void correctAnswerIsCounted() {
        String note = viewModel.getCurrentNote().getValue();

        viewModel.submitAnswer(note);

        assertEquals(Integer.valueOf(1), viewModel.getCorrectCount().getValue());
        assertEquals(Integer.valueOf(0), viewModel.getIncorrectCount().getValue());
        assertEquals(Boolean.TRUE, viewModel.getAnswerResult().getValue().getContentIfNotHandled());
    }

    @Test
    public void wrongAnswerIsCountedAndTheNoteStaysTheSame() {
        String note = viewModel.getCurrentNote().getValue();

        viewModel.submitAnswer("X");

        assertEquals(Integer.valueOf(1), viewModel.getIncorrectCount().getValue());
        assertEquals(note, viewModel.getCurrentNote().getValue());
    }

    @Test
    public void scoreIsSavedOnlyOnceWhenTheTimerFinishesTwice() {
        viewModel.submitAnswer(viewModel.getCurrentNote().getValue());

        timer.listener.onFinish();
        timer.listener.onFinish();

        verify(dao, times(1)).insertScoreSync(any(GameScore.class));
        assertEquals(Integer.valueOf(1), viewModel.getGameFinished().getValue().getContentIfNotHandled());
    }

    @Test
    public void answersAfterTheGameEndedAreIgnored() {
        timer.listener.onFinish();

        viewModel.submitAnswer(viewModel.getCurrentNote().getValue());

        assertEquals(Integer.valueOf(0), viewModel.getCorrectCount().getValue());
    }

    @Test
    public void currentNoteIsPlayedByName() {
        viewModel.playCurrentNote();

        assertEquals(1, player.playedNoteNames.size());
        assertEquals(viewModel.getCurrentNote().getValue(), player.playedNoteNames.get(0));
    }

    @Test
    public void timerIsCancelledWhenTheViewModelIsCleared() {
        viewModel.onCleared();

        assertTrue(timer.cancelled);
    }
}
